//
// Created by Chen Dong on 2021/12/7.
//
#include "errors.h"
#include <stdio.h>
char error1[50] = "Program Finishes";
char error2[50] ="Error! Too many operators!";
char error3[50] ="Error!Too few operators!";
char error4[50] = "Error! Token is NULL!";
char error5[50] ="Error! Input is neither a number nor operator!";
char error6[50] ="Error! Mismatched parentheses!";


char* error_handling[6]={error1,error2,error3,error4,error5,error6};



