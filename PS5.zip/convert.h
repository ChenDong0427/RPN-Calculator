//
// Created by Chen Dong on 2021/12/4.
//

#ifndef PS5_CONVERT_H
#define PS5_CONVERT_H
#include "node.h"
void convert(char* ,char* ,int*);
void removes(char*);
#endif //PS5_CONVERT_H
